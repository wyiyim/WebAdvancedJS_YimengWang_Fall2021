export const data = [
    {
       "id":0,
       "info":"During the spring season, I tend to choose cloth with more bright colors and natural patterns. For the materials, they usually combine different variations of lightweight fabrics including cotton, nylon, and denim.",
       "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2FFrame%201.png?v=1636596242582",
       "title":"Spring",
       "description":"During the spring season, is all about bright colors and natural patterns to embrace the start of the year. "
       
    },
    {
       "id":1,
       "info":" During the summer season, I tend to choose cloth with light colors and large image patterns. For the materials, lightweight cotton and denim are some of the most comfortable materials to keep the body cool.",
       "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2FFrame%202.png?v=1636596244837",
       "title":"Summer",
       "description":"For the summer season, I choose cloth with small icons and animal patterns to be relax in the hot summer weather. "
    },
    {
       "id":2,
       "info":"During the autumn season, I tend to choose cloth with embroidery and animal patterns. For the materials, they usually combine different variations of heavyweight fabrics including cotton, wool, and denim.",
       "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2FFrame%203.png?v=1636596247263",
       "title":"Autumn",
       "description":"During the the autumn, is about embroidered patterns and gorgeous design to weclome this colorful fall season. "
    },
    {
       "id":3,
       "info":" During the winter season, I tend to choose cloth with more darker colors and check-patterns. For the materials, keep warm is the most important for winter so heavyweight cotton, wool, and goose down.",
       "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2FFrame%204.png?v=1636596249586",
       "title":"Winter",
       "description":"For the winter season, I love check-patterns and mix color to have a classic looks for the end of the year."
    }
 ]