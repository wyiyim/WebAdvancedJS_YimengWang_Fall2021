import '../App.css';

const Image = (props) => {


    return (
        <div className="image" id={props.id}>

                <img className="image-img" src={props.source}/>
                <p className="image-title">{props.description}</p>
                
                
                  
        </div>
    )
}


export default Image;