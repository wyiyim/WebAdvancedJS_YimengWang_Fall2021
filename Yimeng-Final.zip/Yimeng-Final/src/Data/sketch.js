export const sketch = [

    {
        "info":"Sketch",
        "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2FSketch.png?v=1639169411484",
        "description":"Sketches"
     }


]






