export const prototype = [

    {
        "info":"Prototype",
        "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2FFlourish.png?v=1639169406602",
        "description":"Flourish graph for IUCN Red List threatened species from 2012 to 2021"
     }


]