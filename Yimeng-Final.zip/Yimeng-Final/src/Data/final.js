export const final = [
    {
       "id":0,
       "info":"",
       "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2F1.png?v=1639360305665",
       "description":""
       
    },
    {
       "id":1,
       "info":"",
       "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2F2.png?v=1639360308485",
       "description":""
    },
    {
       "id":2,
       "info":"",
       "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2F3.png?v=1639360311350",
       "description":""
    },
    {
       "id":3,
       "info":"",
       "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2F4.png?v=1639360313648",
       "description":"Final IUCN Red List infographics"
    }
 ]