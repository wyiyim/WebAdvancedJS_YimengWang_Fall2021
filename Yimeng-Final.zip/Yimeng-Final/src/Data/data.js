export const data = [
    {
       "info":"Dataset",
       "img":"https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2FData.png?v=1639169404538",
       "description":"Raw dataset"
       
    }
 ]