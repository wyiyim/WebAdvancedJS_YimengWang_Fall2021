import './App.css';

import Header from './Components/Header';
import Image from './Components/Image';

import {data} from './Data/data';
import {sketch} from './Data/sketch';
import {prototype} from './Data/prototype';
import {final} from './Data/final';


const App = () => {
  

  return (
 
    <div className="App">

      <Header source="https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2Fheader.png?v=1639168173628"/>

      <h1>Uncertainties: A Data Visualisation of IUCN Red List Threatened Species</h1>
      <h3>Yimeng Wang | Data Vis & Info Aesthetics FA21</h3>

      <a>
        <img className="main-Img" src="https://cdn.glitch.me/62f71ba9-99ab-4e13-affc-194c649e2dd4%2F1.png?v=1639360305665"/>
      </a>

      <p>
        Uncertainties is a four-week-long individual project. The goal for this project was through visualizing raw datasets to tell a story of  “uncertainties”. I chose IUCN red list threatened species as my source datasets to design an infographic data visualization.  Through my visualization, I want to express my concerns about the uncertainty of the environment and bring awareness to the audience.
      </p>

      <h2>Process Datasets from IUCN Red List</h2>

      <p>
      I choose IUCN Red List as the original dataset. Established in 1964, the International Union for Conservation of Nature’s Red List of Threatened Species is the world’s most comprehensive information source on the global extinction risk status of animal, fungus, and plant species. This list is a critical indicator of the health of the world’s biodiversity. 
      </p>
      <p>
        Key datasets from IUCN Red List:
      </p>
      <p> 1. Species categories</p>
      <p> 2. Estimated number of described species </p>
      <p> 3. Number of species evaluated by IUCN </p>
      <p> 4. Number of threatened species </p>

      <div>

      {data.map((data) => {
          

          return (
           
              <Image key = {data.id}
                id={data.id}
                source={data.img}
                description={data.description} 
              />
          
          );
        })
        }

      </div>


      <p> 
      By further evaluating all the raw datasets, I notice that species like vertebrates have a higher percentage of evaluation by IUCN compared to other species which has low percentage of evaluation. This makes some data are hard to use to visualize as a trend because they can’t cover the whole story. So I decided to focus on vertebrate species because they have a higher percentage of evaluation numbers so the data has a better representation of the real situation.   
      </p>

      <h2>Starting with sketches</h2>

      <p>
        Based on the initial analysis of the datasets, I started sketching some ideas on paper to help me figure out the best way to visualize both the quantitive and qualitative aspects of the data. Different styles and forms are being explored during the process, it helps me to sort out the data I need and the story I want to tell through this visualization.
      </p>

    <div>

     {sketch.map((sketch) => {
    

       return (
     
        <Image key = {sketch.id}
          id={sketch.id}
          source={sketch.img}
          description={sketch.description}
        />
    
         );
      })
     }

    </div>

      <p>
        Sketching goes hand in hand with cleaning and analyzing the data. When I draw out and sketch, it makes me realize which data I need. As I started to draw, key pieces of information I want to deliver to the audiences begin to form:  

      </p>
      <p> 1. What can we learn from the threatened species number over the years?</p>
      <p> 2. What are the key factors contributing to the trend? </p>
      <p> 3. How do different species threaten numbers compare with each other? </p>
      <p> 4. Within each species, what are the relations between critically endangered, endangered, and vulnerable? </p>

      <h2>Using Flourish to create prototypes</h2>

      <p>
        I started the prototyping process by putting the datasets into Flourish to create a line chart. From this line chart, we can see that not all species threatened numbers go higher over the years. This makes me realised that I needed to add in some more context regarding the reasons for the threatened species number increase.

      </p>

      <div>

        {prototype.map((prototype) => {


         return (

          <Image key = {prototype.id}
            id={prototype.id}
            source={prototype.img}
            description={prototype.description}
            />
            
          );
          })
          
        }
        
        </div>

      <h2>Synthesis and designing the final data visualization</h2>

      <p>
      By putting the raw datasets from IUCN into Flourish, I create multiple charts to help me have a better view of the data. It was such a quick process once my data was clean,  I can start refining and designing the final infographic. 
      </p>

      <p>
      After creating the first iteration of the data visualization,  I shared my design with close colleagues and friends to conduct user testing, check if the graphic makes sense, is the information readable from a design and narrative perspective, and also that the back end of the data is correct.

      </p>

      <p>
      I gathered lots of useful feedback from the user testing to help me improve the design. Some key takeaways are, first, because the infographic has multiple line charts presented, there needs to be a connection between each chart whether is using the same color or style to unify them. Second, some additional information needs to be provided to help explain the data, explain the reason for the threatened number going up or down and give a context for the story. Last, make sure the design is not overcomplicating, sometimes less is more, a simple design can help the audience easier to understand.

      </p>

      <h2>The final data visualizations</h2>

      <div>

        {final.map((final) => {


        return (

        <Image key = {final.id}
        id={final.id}
        source={final.img}
        description={final.description}
    />
     );
    })
    }
    
    </div>

      <p>
      Designing this infographic was a great learning experience and rewarding in the end. Not just learning how to turn raw data into a visualization, but also enabled me the opportunity to have a closer look at the fragile environment and endanger species. I hope that through my visualization, I can send a clear message to the audience that we need to take action to protect and preserve biodiversity for the future.
      </p>


      <h4>
        <a href="https://www.iucnredlist.org/">Source: IUCN Red List</a>
       </h4>

   
    </div>
    
  );
}

export default App;
